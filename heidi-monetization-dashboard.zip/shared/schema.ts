import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name").notNull().default("Creator"),
  bio: text("bio").default(""),
  avatarUrl: text("avatar_url").default(""),
  level: integer("level").notNull().default(1),
  dragonPoints: integer("dragon_points").notNull().default(0),
  pointsTier: text("points_tier").notNull().default("Bronze"),
  heidiAutonomy: integer("heidi_autonomy").notNull().default(60),
  heidiPersonality: text("heidi_personality").notNull().default("professional"),
  heidiVoice: text("heidi_voice").notNull().default("v2"),
  autoClip: boolean("auto_clip").notNull().default(true),
  autoComment: boolean("auto_comment").notNull().default(false),
  stripeConnected: boolean("stripe_connected").notNull().default(false),
  paypalConnected: boolean("paypal_connected").notNull().default(false),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  displayName: true,
});
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const earnings = pgTable("earnings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  type: text("type").notNull(), // subscription, tip, ad, merch
  amount: real("amount").notNull(),
  source: text("source").notNull(), // username or label
  description: text("description").default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertEarningSchema = createInsertSchema(earnings).omit({ id: true, createdAt: true });
export type InsertEarning = z.infer<typeof insertEarningSchema>;
export type Earning = typeof earnings.$inferSelect;

export const subscriptionTiers = pgTable("subscription_tiers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  name: text("name").notNull(),
  price: real("price").notNull(),
  perks: text("perks").array().notNull().default(sql`'{}'::text[]`),
  isPopular: boolean("is_popular").notNull().default(false),
  subscriberCount: integer("subscriber_count").notNull().default(0),
});

export const insertTierSchema = createInsertSchema(subscriptionTiers).omit({ id: true });
export type InsertTier = z.infer<typeof insertTierSchema>;
export type SubscriptionTier = typeof subscriptionTiers.$inferSelect;

export const dragonQuests = pgTable("dragon_quests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  title: text("title").notNull(),
  reward: integer("reward").notNull(),
  progress: integer("progress").notNull().default(0),
  target: integer("target").notNull().default(100),
  status: text("status").notNull().default("active"), // active, claimed
});

export const insertQuestSchema = createInsertSchema(dragonQuests).omit({ id: true });
export type InsertQuest = z.infer<typeof insertQuestSchema>;
export type DragonQuest = typeof dragonQuests.$inferSelect;

export const communityPosts = pgTable("community_posts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  authorName: text("author_name").notNull(),
  authorAvatar: text("author_avatar").default(""),
  authorTier: text("author_tier").default("Free"),
  content: text("content").notNull(),
  likes: integer("likes").notNull().default(0),
  replies: integer("replies").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertPostSchema = createInsertSchema(communityPosts).omit({ id: true, createdAt: true });
export type InsertPost = z.infer<typeof insertPostSchema>;
export type CommunityPost = typeof communityPosts.$inferSelect;

export const analyticsSnapshots = pgTable("analytics_snapshots", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  metric: text("metric").notNull(), // viewers, likes, comments
  value: real("value").notNull(),
  label: text("label").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertAnalyticsSchema = createInsertSchema(analyticsSnapshots).omit({ id: true, createdAt: true });
export type InsertAnalytics = z.infer<typeof insertAnalyticsSchema>;
export type AnalyticsSnapshot = typeof analyticsSnapshots.$inferSelect;
