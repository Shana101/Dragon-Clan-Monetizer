import { 
  type User, type InsertUser,
  type Earning, type InsertEarning,
  type SubscriptionTier, type InsertTier,
  type DragonQuest, type InsertQuest,
  type CommunityPost, type InsertPost,
  type AnalyticsSnapshot, type InsertAnalytics,
  users, earnings, subscriptionTiers, dragonQuests, communityPosts, analyticsSnapshots
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, data: Partial<User>): Promise<User | undefined>;

  getEarnings(userId: string): Promise<Earning[]>;
  createEarning(earning: InsertEarning): Promise<Earning>;

  getTiers(userId: string): Promise<SubscriptionTier[]>;
  createTier(tier: InsertTier): Promise<SubscriptionTier>;
  updateTier(id: string, data: Partial<SubscriptionTier>): Promise<SubscriptionTier | undefined>;

  getQuests(userId: string): Promise<DragonQuest[]>;
  createQuest(quest: InsertQuest): Promise<DragonQuest>;
  updateQuest(id: string, data: Partial<DragonQuest>): Promise<DragonQuest | undefined>;

  getPosts(userId: string): Promise<CommunityPost[]>;
  createPost(post: InsertPost): Promise<CommunityPost>;
  likePost(id: string): Promise<CommunityPost | undefined>;

  getAnalytics(userId: string, metric?: string): Promise<AnalyticsSnapshot[]>;
  createAnalytics(snapshot: InsertAnalytics): Promise<AnalyticsSnapshot>;
}

const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool);

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: string, data: Partial<User>): Promise<User | undefined> {
    const [user] = await db.update(users).set(data).where(eq(users.id, id)).returning();
    return user;
  }

  async getEarnings(userId: string): Promise<Earning[]> {
    return db.select().from(earnings).where(eq(earnings.userId, userId)).orderBy(desc(earnings.createdAt));
  }

  async createEarning(earning: InsertEarning): Promise<Earning> {
    const [row] = await db.insert(earnings).values(earning).returning();
    return row;
  }

  async getTiers(userId: string): Promise<SubscriptionTier[]> {
    return db.select().from(subscriptionTiers).where(eq(subscriptionTiers.userId, userId));
  }

  async createTier(tier: InsertTier): Promise<SubscriptionTier> {
    const [row] = await db.insert(subscriptionTiers).values(tier).returning();
    return row;
  }

  async updateTier(id: string, data: Partial<SubscriptionTier>): Promise<SubscriptionTier | undefined> {
    const [row] = await db.update(subscriptionTiers).set(data).where(eq(subscriptionTiers.id, id)).returning();
    return row;
  }

  async getQuests(userId: string): Promise<DragonQuest[]> {
    return db.select().from(dragonQuests).where(eq(dragonQuests.userId, userId));
  }

  async createQuest(quest: InsertQuest): Promise<DragonQuest> {
    const [row] = await db.insert(dragonQuests).values(quest).returning();
    return row;
  }

  async updateQuest(id: string, data: Partial<DragonQuest>): Promise<DragonQuest | undefined> {
    const [row] = await db.update(dragonQuests).set(data).where(eq(dragonQuests.id, id)).returning();
    return row;
  }

  async getPosts(userId: string): Promise<CommunityPost[]> {
    return db.select().from(communityPosts).where(eq(communityPosts.userId, userId)).orderBy(desc(communityPosts.createdAt));
  }

  async createPost(post: InsertPost): Promise<CommunityPost> {
    const [row] = await db.insert(communityPosts).values(post).returning();
    return row;
  }

  async likePost(id: string): Promise<CommunityPost | undefined> {
    const [existing] = await db.select().from(communityPosts).where(eq(communityPosts.id, id));
    if (!existing) return undefined;
    const [row] = await db.update(communityPosts).set({ likes: existing.likes + 1 }).where(eq(communityPosts.id, id)).returning();
    return row;
  }

  async getAnalytics(userId: string, metric?: string): Promise<AnalyticsSnapshot[]> {
    if (metric) {
      return db.select().from(analyticsSnapshots)
        .where(eq(analyticsSnapshots.userId, userId))
        .orderBy(desc(analyticsSnapshots.createdAt));
    }
    return db.select().from(analyticsSnapshots)
      .where(eq(analyticsSnapshots.userId, userId))
      .orderBy(desc(analyticsSnapshots.createdAt));
  }

  async createAnalytics(snapshot: InsertAnalytics): Promise<AnalyticsSnapshot> {
    const [row] = await db.insert(analyticsSnapshots).values(snapshot).returning();
    return row;
  }
}

export const storage = new DatabaseStorage();
